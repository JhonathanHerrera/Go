package main

import "fmt"

func main() { 

	message := "Hello"
	name := "Jhoanthan"
	space := " "
	fmt.Println(message +space + name)
}